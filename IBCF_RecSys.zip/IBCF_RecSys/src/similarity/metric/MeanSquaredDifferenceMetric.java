/*
 Computes mean squared difference similarity metric
 */

package similarity.metric;

import java.util.Set;

import profile.Profile;

public class MeanSquaredDifferenceMetric implements SimilarityMetric
{
	/**
	 * constructor 
	 */
	private double rati_min=0;
	private double rati_max=0;
	
	public MeanSquaredDifferenceMetric(double rat_min, double rat_max)
	{	
		rati_min=rat_min;
		rati_max=rat_max;
	}
	public double getSimilarity(final Profile p1, final Profile p2)
	{
        double numerator = 0;
        double denominator = 0;
        double msd=0;
        double msd_metric=0;
        
        Set<Integer> common = p1.getCommonIds(p2);
		for(Integer id: common)
		{
			double r1 = p1.getValue(id).doubleValue();
			double r2 = p2.getValue(id).doubleValue();
			numerator += Math.pow((r1-r2), 2);
		}
		
		denominator=common.size();
		
		if(denominator==0)
		{
			return 0;
		}
		
		msd= numerator/denominator;
		
		msd_metric=1-(msd/(Math.pow((rati_max - rati_min), 2)));
		
		return msd_metric;
	}
}

