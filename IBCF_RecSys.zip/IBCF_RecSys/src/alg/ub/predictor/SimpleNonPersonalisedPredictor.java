package alg.ub.predictor;

import java.util.Map;

import alg.ub.neighbourhood.Neighbourhood;
import profile.Profile;
import similarity.SimilarityMap;

public class SimpleNonPersonalisedPredictor implements Predictor {

	public SimpleNonPersonalisedPredictor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double getPrediction(Integer userId, Integer itemId, Map<Integer, Profile> userProfileMap,
			Map<Integer, Profile> itemProfileMap, Neighbourhood neighbourhood, SimilarityMap simMap) 
	{
		 double denominator=0;
		 double numerator=0;
		 
		Profile p=itemProfileMap.get(itemId);
		denominator=p.getSize();
		for(int i: p.getIds())
		{
			numerator+=p.getValue(i);
		}
		
		if(denominator==0)
		{
			return null;
		}
		
		return numerator/denominator;
	}

}
