package alg.ub.predictor;

import java.util.Map;
import java.util.Set;

import alg.ub.neighbourhood.Neighbourhood;
import profile.Profile;
import similarity.SimilarityMap;

public class DeviationFromUserMeanPredictor implements Predictor {

	public DeviationFromUserMeanPredictor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double getPrediction(Integer userId, Integer itemId, Map<Integer, Profile> userProfileMap,
			Map<Integer, Profile> itemProfileMap, Neighbourhood neighbourhood, SimilarityMap simMap)
	{
		double denominator=0;
		 double numerator=0;
		 
		 Set<Integer> neighbour= neighbourhood.getNeighbours(userId);
		 
		 if(neighbour == null)
		 {
			 return null;
		 }
		 
		 double user_mean_rating=userProfileMap.get(userId).getMeanValue();
		 
		 for(int i:neighbour)
		 {
			 Double neigh_rating=userProfileMap.get(i).getValue(itemId);
			 double mean_rating=userProfileMap.get(i).getMeanValue();
					 
			 if(neigh_rating == null)
			 {
				 numerator+=0;
				 denominator+=0;
			 }
			 else
			 {
				 
			 numerator+= simMap.getSimilarity(userId,i) * (neigh_rating - mean_rating) ;
			 denominator+=Math.abs(simMap.getSimilarity(userId, i));
		 
			 }
		 }
		 if(denominator==0)
			{
				return null;
			}
			
			return user_mean_rating+(numerator/denominator);
	}

}
